CS 143: Project 1C - Movie database
Kang Chen
Matthew Lin

In this project, Kang was primarily responsible for inserting into the database (ex. addMovieInfo, addActorDirector, addMovieComment, addMovieDirector, addMovieActor). Matthew was primarily responsible for the search features (ex. search.php) and showing the actor / movie information, and linking relationships together using href (ex. showActorInfo, showMovieInfo). 

Project Criteria:
We feel that we have made all the basic implementation that a movie database would use. It is intuitive to use, because we clearly labeled what each functionality does. In addition, all the attributes of each table are clearly defined on the web page.

Places for improvement:
We did not have enough time to incorporate a nice user interface, but our website is easy to follow, and we have implemented all the backend specificiations. If given more time, we plan to incorporate more css and make a navigation menu, that would be a lot cleaner, and easier to follow. 